import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="container py-12 md:py-16 space-y-16">
      <section>
        <h1 className="text-4xl font-bold mb-6">About Me</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-lg">
              I'm Mahdi Bouakline, a Software Engineer with a passion for cybersecurity, data analysis, and cloud
              technologies. Currently working at Public Safety Canada in the Cybersecurity Resilience and Exploitation
              division, I focus on developing secure software solutions and implementing robust cloud infrastructure.
            </p>
            <p className="text-lg">
              With a background in Software Engineering and Economics from Carleton University, I bring a unique
              perspective that combines technical expertise with business acumen. My experience spans software
              development, data analysis, and cloud enablement, allowing me to tackle complex challenges with a holistic
              approach.
            </p>
            <p className="text-lg">
              I'm passionate about leveraging technology to solve real-world problems and enhance security postures. My
              multilingual skills (English, French, Kabyle) and Top Secret Enhanced Security Clearance enable me to work
              effectively in diverse and sensitive environments.
            </p>
          </div>
          <div className="relative aspect-square w-full max-w-md mx-auto">
            <Image
              src="/placeholder.svg?height=600&width=600"
              alt="Mahdi Bouakline"
              fill
              className="object-cover rounded-xl shadow-lg"
            />
          </div>
        </div>
      </section>

      <section className="space-y-8">
        <h2 className="text-3xl font-bold">Professional Journey</h2>
        <div className="space-y-6">
          <p className="text-lg">
            My professional journey began at Public Safety Canada, where I've had the opportunity to work across
            multiple divisions, gaining diverse experience in software engineering, data analysis, and cloud
            infrastructure.
          </p>
          <p className="text-lg">
            As a Data Analyst, I managed data for over 250 projects, developed Power BI dashboards, and provided
            critical insights to support executive decision-making. This role honed my ability to translate complex data
            into actionable intelligence.
          </p>
          <p className="text-lg">
            In the Cloud Enablement and DevOps division, I modernized shared services infrastructure, deployed new
            servers, and implemented automated monitoring solutions. This experience deepened my understanding of cloud
            technologies and DevOps practices.
          </p>
          <p className="text-lg">
            Currently, in the Cybersecurity Resilience and Exploitation division, I focus on developing secure software
            solutions and implementing robust security measures to protect critical infrastructure. This role combines
            my technical skills with a strategic approach to cybersecurity.
          </p>
        </div>
      </section>

      <section className="space-y-8">
        <h2 className="text-3xl font-bold">Education & Continuous Learning</h2>
        <div className="space-y-6">
          <p className="text-lg">
            I'm currently pursuing a Bachelor of Engineering in Software Engineering with a minor in Economics at
            Carleton University, expected to graduate in May 2026. This interdisciplinary education provides me with
            both technical depth and business context.
          </p>
          <p className="text-lg">
            Beyond formal education, I'm committed to continuous learning and staying current with emerging technologies
            and security practices. I regularly engage with professional communities and pursue self-directed learning
            to expand my knowledge and skills.
          </p>
        </div>
      </section>

      <section className="space-y-8">
        <h2 className="text-3xl font-bold">Personal Approach</h2>
        <div className="space-y-6">
          <p className="text-lg">
            I approach challenges with a combination of analytical thinking, creativity, and attention to detail. I
            believe in building solutions that are not only technically sound but also user-focused and
            business-aligned.
          </p>
          <p className="text-lg">
            Collaboration is central to my work style. I thrive in cross-functional teams and enjoy the process of
            bringing diverse perspectives together to solve complex problems.
          </p>
          <p className="text-lg">
            I'm driven by a desire to make meaningful contributions to cybersecurity and technology innovation. I'm
            particularly interested in projects that have real-world impact and enhance security postures.
          </p>
        </div>
      </section>

      <div className="flex justify-center">
        <Button asChild>
          <Link href="/experience">
            View My Experience <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

