import Link from "next/link"
import Image from "next/image"
import { ArrowRight, ExternalLink, Github } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function ProjectsPage() {
  const projects = [
    {
      title: "Financial Sentiment Analysis & Stock Ranking System",
      description:
        "A machine learning project that applies NLP techniques to analyze sentiment in financial news and social media, providing real-time insights and stock rankings for S&P 500 companies.",
      image: "/placeholder.svg?height=400&width=600",
      period: "February 2024 - March 2024",
      technologies: ["Python", "JavaScript", "React", "HTML", "CSS", "NLP", "TF-IDF"],
      highlights: [
        "Collaborated with a team to develop a financial sentiment analysis model",
        "Transformed the model into an interactive website for real-time insights",
        "Achieved high accuracy on validation and test sets using TF-IDF for feature extraction",
        "Implemented a ranking system to help users identify potential investment opportunities",
      ],
      links: {
        github: "#",
        demo: "#",
      },
    },
    {
      title: "Data Visualization Model",
      description:
        "A Python program for data extraction, manipulation, and visualization from CSV and TXT files, providing insights through interactive charts and graphs.",
      image: "/placeholder.svg?height=400&width=600",
      period: "January 2023 - April 2023",
      technologies: ["Python", "Matplotlib", "NumPy", "SciPy", "Data Visualization"],
      highlights: [
        "Led a team of four in developing a comprehensive data visualization solution",
        "Provided coaching and support to team members, ensuring timely completion",
        "Applied Python libraries for sorting, plotting, and visualizing complex data",
        "Created an intuitive interface for non-technical users to interact with data",
      ],
      links: {
        github: "#",
      },
    },
    {
      title: "Server Health Monitoring System",
      description:
        "An automated system for monitoring server health metrics, exporting data to Power BI for visualization, and sending daily email reports to stakeholders.",
      image: "/placeholder.svg?height=400&width=600",
      period: "October 2024 - December 2024",
      technologies: ["PowerShell", "Power BI", "Server Management", "Automation"],
      highlights: [
        "Developed an automated solution for monitoring critical server health metrics",
        "Created comprehensive Power BI dashboards for visualizing performance data",
        "Implemented daily email reporting to keep stakeholders informed",
        "Reduced manual monitoring time by 85% through automation",
      ],
      links: {},
    },
  ]

  return (
    <div className="container py-12 md:py-16 space-y-12">
      <section className="space-y-6">
        <h1 className="text-4xl font-bold">Projects</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          Here are some of the key projects I've worked on, showcasing my skills in software development, data analysis,
          and cybersecurity.
        </p>
      </section>

      <section className="grid grid-cols-1 gap-8">
        {projects.map((project, index) => (
          <Card key={index} className="overflow-hidden border shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="relative h-64 md:h-full">
                <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
              </div>
              <div className="flex flex-col p-6">
                <CardHeader className="p-0 pb-4">
                  <div className="flex flex-col gap-2">
                    <CardTitle className="text-2xl">{project.title}</CardTitle>
                    <Badge variant="outline" className="w-fit">
                      {project.period}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0 space-y-4 flex-grow">
                  <CardDescription className="text-base">{project.description}</CardDescription>
                  <div>
                    <h3 className="font-medium mb-2">Key Highlights:</h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {project.highlights.map((highlight, i) => (
                        <li key={i}>{highlight}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Technologies:</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, i) => (
                        <Badge key={i} variant="secondary">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-0 pt-4 flex gap-4">
                  {project.links.github && (
                    <Button variant="outline" size="sm" asChild>
                      <Link href={project.links.github} target="_blank" rel="noopener noreferrer">
                        <Github className="mr-2 h-4 w-4" /> GitHub
                      </Link>
                    </Button>
                  )}
                  {project.links.demo && (
                    <Button size="sm" asChild>
                      <Link href={project.links.demo} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="mr-2 h-4 w-4" /> Live Demo
                      </Link>
                    </Button>
                  )}
                </CardFooter>
              </div>
            </div>
          </Card>
        ))}
      </section>

      <div className="flex justify-center">
        <Button asChild>
          <Link href="/skills">
            View My Skills <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

