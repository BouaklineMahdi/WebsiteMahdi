import Link from "next/link"
import Image from "next/image"
import { Github, Linkedin, Mail, ArrowRight, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-secondary/10 dark:from-primary/5 dark:to-secondary/5" />
        <div className="container relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="flex flex-col space-y-6">
              <div className="space-y-2">
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Mahdi Bouakline</h1>
                <div className="flex items-center text-muted-foreground">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>Ottawa, Ontario</span>
                </div>
              </div>

              <h2 className="text-2xl md:text-3xl font-medium text-primary">
                Software Engineer & Cybersecurity Specialist
              </h2>

              <p className="text-lg text-muted-foreground">
                Currently working at Public Safety Canada in Cybersecurity Resilience and Exploitation, focusing on
                software development, data analysis, and cloud infrastructure.
              </p>

              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Software Engineering</Badge>
                <Badge variant="secondary">Data Analysis</Badge>
                <Badge variant="secondary">Cybersecurity</Badge>
                <Badge variant="secondary">Cloud Infrastructure</Badge>
                <Badge variant="secondary">DevOps</Badge>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild>
                  <Link href="/contact">
                    Get in Touch <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/projects">View Projects</Link>
                </Button>
              </div>

              <div className="flex items-center space-x-4">
                <Link
                  href="https://github.com/mahdibouakline"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  <Github className="h-5 w-5" />
                  <span className="sr-only">GitHub</span>
                </Link>
                <Link
                  href="https://linkedin.com/in/mahdibouakline"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </Link>
                <Link
                  href="mailto:bouaklinemahdi@gmail.com"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  <Mail className="h-5 w-5" />
                  <span className="sr-only">Email</span>
                </Link>
              </div>
            </div>

            <div className="relative aspect-square w-full max-w-md mx-auto">
              <Image
                src="/placeholder.svg?height=600&width=600"
                alt="Mahdi Bouakline"
                fill
                className="object-cover rounded-xl shadow-lg"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* Summary Section */}
      <section className="py-16 bg-muted/50">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold">Current Role</h2>
            <p className="text-lg text-muted-foreground">
              As a Software Engineer at Public Safety Canada in the Cybersecurity Resilience and Exploitation division,
              I develop secure software solutions, analyze data for security insights, and implement cloud
              infrastructure to enhance Canada's cybersecurity posture. My work combines technical expertise with a
              strategic approach to protect critical systems and data.
            </p>
            <Button asChild>
              <Link href="/about">
                Learn More About Me <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Skills */}
      <section className="py-16">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Core Expertise</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Software Development",
                description:
                  "Proficient in Python, Java, C++, Golang, and more, with experience in building secure, scalable applications.",
                icon: "💻",
              },
              {
                title: "Data Analysis",
                description:
                  "Experience in managing and analyzing large datasets, creating visualizations, and deriving actionable insights.",
                icon: "📊",
              },
              {
                title: "Cloud & DevOps",
                description:
                  "Skilled in AWS, Azure, Jenkins, Kubernetes, and other cloud and CI/CD tools for robust infrastructure.",
                icon: "☁️",
              },
            ].map((skill, index) => (
              <div key={index} className="bg-card rounded-lg p-6 shadow-sm border">
                <div className="text-4xl mb-4">{skill.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{skill.title}</h3>
                <p className="text-muted-foreground">{skill.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold">Available for New Opportunities</h2>
            <p className="text-lg opacity-90">
              Starting May 2025, I'll be available for new challenges and opportunities. I'm open to relocation and
              excited to bring my skills to innovative projects.
            </p>
            <Button variant="secondary" asChild>
              <Link href="/contact">Contact Me</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

