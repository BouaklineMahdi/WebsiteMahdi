import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function SkillsPage() {
  const skillCategories = [
    {
      category: "Programming Languages",
      skills: [
        { name: "Python", level: 95 },
        { name: "Java", level: 90 },
        { name: "C/C++", level: 85 },
        { name: "Golang", level: 80 },
        { name: "JavaScript", level: 75 },
        { name: "React", level: 70 },
        { name: "HTML/CSS", level: 85 },
        { name: "Perl", level: 65 },
      ],
    },
    {
      category: "DevOps & CI/CD Tools",
      skills: [
        { name: "Jenkins", level: 85 },
        { name: "Kubernetes", level: 80 },
        { name: "Git", level: 90 },
        { name: "PowerShell", level: 85 },
        { name: "Linux", level: 90 },
        { name: "Kibana", level: 75 },
        { name: "Jira", level: 80 },
      ],
    },
    {
      category: "Cloud & Infrastructure",
      skills: [
        { name: "VMware", level: 85 },
        { name: "KVM", level: 80 },
        { name: "Microsoft SQL Server", level: 75 },
        { name: "AWS", level: 80 },
        { name: "Azure", level: 85 },
        { name: "GCP", level: 70 },
      ],
    },
    {
      category: "Data Analysis & Visualization",
      skills: [
        { name: "Power BI", level: 90 },
        { name: "Data Modeling", level: 85 },
        { name: "Statistical Analysis", level: 80 },
        { name: "Matplotlib", level: 85 },
        { name: "NumPy", level: 90 },
        { name: "SciPy", level: 85 },
      ],
    },
    {
      category: "Additional Expertise",
      skills: [
        { name: "Cybersecurity", level: 90 },
        { name: "ARM Architecture", level: 75 },
        { name: "Microcontroller Architecture", level: 70 },
        { name: "Project Management", level: 85 },
        { name: "Technical Documentation", level: 90 },
      ],
    },
  ]

  return (
    <div className="container py-12 md:py-16 space-y-12">
      <section className="space-y-6">
        <h1 className="text-4xl font-bold">Technical Skills</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          I've developed a diverse set of technical skills throughout my education and professional experience. Here's a
          comprehensive overview of my capabilities across various domains.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {skillCategories.map((category, index) => (
          <Card key={index} className="border shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl">{category.category}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {category.skills.map((skill, i) => (
                <div key={i} className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-muted-foreground">{skill.level}%</span>
                  </div>
                  <Progress value={skill.level} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="bg-muted/50 p-8 rounded-lg">
        <div className="max-w-3xl mx-auto space-y-6">
          <h2 className="text-2xl font-bold text-center">Languages</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            {[
              { language: "English", proficiency: "Native" },
              { language: "French", proficiency: "Fluent" },
              { language: "Kabyle", proficiency: "Native" },
            ].map((lang, index) => (
              <div key={index} className="p-4 bg-card rounded-lg border shadow-sm">
                <h3 className="text-lg font-medium">{lang.language}</h3>
                <p className="text-muted-foreground">{lang.proficiency}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="space-y-6">
        <h2 className="text-3xl font-bold text-center">Continuous Learning</h2>
        <p className="text-lg text-muted-foreground text-center max-w-3xl mx-auto">
          I'm committed to continuous learning and staying current with emerging technologies and best practices. I
          regularly engage with professional communities, pursue self-directed learning, and explore new tools and
          frameworks to expand my knowledge and skills.
        </p>
      </section>

      <div className="flex justify-center">
        <Button asChild>
          <Link href="/education">
            View My Education <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

