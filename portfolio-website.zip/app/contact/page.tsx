"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Github, Linkedin, Mail, MapPin, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function ContactPage() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Message sent!",
      description: "Thank you for reaching out. I'll get back to you soon.",
    })

    setIsSubmitting(false)
    ;(e.target as HTMLFormElement).reset()
  }

  return (
    <div className="container py-12 md:py-16 space-y-12">
      <section className="space-y-6">
        <h1 className="text-4xl font-bold">Contact Me</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          I'm interested in new opportunities starting May 2025. Whether you have a question or just want to say hello,
          I'll do my best to get back to you!
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle className="text-2xl">Get in Touch</CardTitle>
            <CardDescription>Fill out the form and I'll get back to you as soon as possible.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" placeholder="Your name" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="Your email" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input id="subject" placeholder="Subject" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea id="message" placeholder="Your message" rows={5} required />
              </div>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>Sending...</>
                ) : (
                  <>
                    Send Message <Send className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle className="text-2xl">Contact Information</CardTitle>
            <CardDescription>Here are the ways you can reach me directly.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <Mail className="h-5 w-5 mt-0.5 text-primary" />
                <div>
                  <h3 className="font-medium">Email</h3>
                  <p className="text-muted-foreground">
                    <Link href="mailto:bouaklinemahdi@gmail.com" className="hover:text-primary">
                      bouaklinemahdi@gmail.com
                    </Link>
                  </p>
                  <p className="text-muted-foreground">
                    <Link href="mailto:mahdibouakline@cmail.carleton.ca" className="hover:text-primary">
                      mahdibouakline@cmail.carleton.ca
                    </Link>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <MapPin className="h-5 w-5 mt-0.5 text-primary" />
                <div>
                  <h3 className="font-medium">Location</h3>
                  <p className="text-muted-foreground">Ottawa, Ontario, Canada</p>
                  <p className="text-muted-foreground">Open to relocation</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Linkedin className="h-5 w-5 mt-0.5 text-primary" />
                <div>
                  <h3 className="font-medium">LinkedIn</h3>
                  <p className="text-muted-foreground">
                    <Link
                      href="https://linkedin.com/in/mahdibouakline"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary"
                    >
                      linkedin.com/in/mahdibouakline
                    </Link>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Github className="h-5 w-5 mt-0.5 text-primary" />
                <div>
                  <h3 className="font-medium">GitHub</h3>
                  <p className="text-muted-foreground">
                    <Link
                      href="https://github.com/mahdibouakline"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary"
                    >
                      github.com/mahdibouakline
                    </Link>
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t">
              <h3 className="font-medium mb-2">Availability</h3>
              <p className="text-muted-foreground">
                Available for work starting May 2025. Open to relocation and eligible to work in Canada, France (French
                long-term visa), and the U.S. (Canadian citizenship).
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

