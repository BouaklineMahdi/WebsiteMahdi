import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function ExperiencePage() {
  const experiences = [
    {
      title: "Software Engineer",
      company: "Public Safety Canada",
      department: "Cybersecurity Resilience and Exploitation",
      period: "April 2025 - Present",
      description: [
        "Developing secure software solutions to enhance Canada's cybersecurity posture.",
        "Implementing and maintaining robust cloud infrastructure for critical systems.",
        "Conducting security assessments and vulnerability testing to identify and address potential threats.",
        "Collaborating with cross-functional teams to develop comprehensive security strategies.",
      ],
      skills: ["Software Development", "Cybersecurity", "Cloud Infrastructure", "Security Assessment"],
    },
    {
      title: "Data Analyst",
      company: "Public Safety Canada",
      department: "Office of the Chief Information Officer",
      period: "January 2025 - April 2025",
      description: [
        "Managed and maintained comprehensive project data for over 250 projects as part of the department's technical Project Management Office (PMO).",
        "Developed Power BI dashboards and Python-based visualizations for diverse stakeholders to deliver insights on project performance.",
        "Monitored project progress metrics, identified trends, and provided recommendations to improve operational efficiency.",
        "Facilitated the seamless closure of the fiscal year by reconciling financial data and updating project metrics.",
        "Led the training and deployment of ServiceNow Capacity Planning across department at an enterprise scale.",
        "Assisted multiple branches in developing new Outcomes & Key Results (OKRs) to establish clear, measurable objectives.",
      ],
      skills: ["Data Analysis", "Power BI", "Python", "Project Management", "ServiceNow", "OKRs"],
    },
    {
      title: "Software Developer",
      company: "Public Safety Canada",
      department: "Cloud Enablement and DevOps",
      period: "October 2024 - December 2024",
      description: [
        "Enabled and configured collaborative workspace servers, while developing standardized procedures for future reference.",
        "Developed, supported and maintained collaborative workspace infrastructure to guarantee performance quality.",
        "Modernized shared services infrastructure by deploying new servers, migrating critical data, and optimizing system upgrades.",
        "Tested and validated secure, cloud-enabled infrastructure, prioritizing comprehensive risk mitigation strategies.",
        "Automated server health monitoring using PowerShell, exporting key metrics to Power BI for enhanced visualization.",
      ],
      skills: ["Software Development", "Cloud Infrastructure", "DevOps", "PowerShell", "Server Management"],
    },
  ]

  return (
    <div className="container py-12 md:py-16 space-y-12">
      <section className="space-y-6">
        <h1 className="text-4xl font-bold">Professional Experience</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          My professional journey has focused on software engineering, data analysis, and cybersecurity at Public Safety
          Canada, where I've contributed to various projects across different divisions.
        </p>
      </section>

      <section className="space-y-8">
        {experiences.map((exp, index) => (
          <Card key={index} className="border shadow-sm">
            <CardHeader>
              <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                <div>
                  <CardTitle className="text-2xl">{exp.title}</CardTitle>
                  <CardDescription className="text-base mt-1">
                    {exp.company} - {exp.department}
                  </CardDescription>
                </div>
                <Badge variant="outline" className="text-sm md:text-base w-fit">
                  {exp.period}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Responsibilities & Achievements:</h3>
                <ul className="list-disc pl-5 space-y-2">
                  {exp.description.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-medium mb-2">Key Skills:</h3>
                <div className="flex flex-wrap gap-2">
                  {exp.skills.map((skill, i) => (
                    <Badge key={i} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="bg-muted/50 p-8 rounded-lg">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-2xl font-bold">Security Clearance</h2>
          <p className="text-lg">
            I hold a Top Secret Enhanced Security Clearance, allowing me to work on sensitive projects and handle
            classified information with the highest level of security.
          </p>
          <h2 className="text-2xl font-bold">Availability</h2>
          <p className="text-lg">
            I'll be available for new opportunities starting May 2025. I'm open to relocation and eligible to work in
            Canada, France (French long-term visa), and the U.S. (Canadian citizenship).
          </p>
        </div>
      </section>

      <div className="flex justify-center">
        <Button asChild>
          <Link href="/projects">
            View My Projects <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

