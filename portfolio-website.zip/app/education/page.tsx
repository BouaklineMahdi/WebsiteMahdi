import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function EducationPage() {
  return (
    <div className="container py-12 md:py-16 space-y-12">
      <section className="space-y-6">
        <h1 className="text-4xl font-bold">Education</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          My educational background combines technical expertise in software engineering with business acumen through
          economics, providing a well-rounded foundation for my career.
        </p>
      </section>

      <section>
        <Card className="border shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="relative h-64 md:h-auto">
              <Image
                src="/placeholder.svg?height=400&width=300"
                alt="Carleton University"
                fill
                className="object-cover"
              />
            </div>
            <div className="md:col-span-2 p-6">
              <CardHeader className="p-0 pb-4">
                <div className="space-y-2">
                  <CardTitle className="text-2xl">Bachelor of Engineering in Software Engineering</CardTitle>
                  <CardDescription className="text-base">Carleton University, Ottawa, Ontario</CardDescription>
                  <div className="flex items-center text-muted-foreground">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>Expected Graduation: May 2026</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 pt-4 space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Program Highlights:</h3>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Pursuing a minor in Economics to complement technical skills with business acumen</li>
                    <li>Currently in 3rd year standing with a strong academic record</li>
                    <li>
                      Coursework includes software design, algorithms, data structures, operating systems, and more
                    </li>
                    <li>Participating in team-based projects to develop collaborative problem-solving skills</li>
                    <li>Applying theoretical knowledge to practical applications through hands-on projects</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-medium mb-2">Key Areas of Study:</h3>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "Software Design",
                      "Algorithms",
                      "Data Structures",
                      "Operating Systems",
                      "Database Systems",
                      "Computer Networks",
                      "Software Testing",
                      "Microeconomics",
                      "Macroeconomics",
                    ].map((area, i) => (
                      <Badge key={i} variant="secondary">
                        {area}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </div>
          </div>
        </Card>
      </section>

      <section className="space-y-8">
        <h2 className="text-3xl font-bold">Professional Development</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            {
              title: "Cloud Computing Certification",
              organization: "AWS",
              date: "2024",
              description: "Comprehensive training in cloud architecture, deployment, and management.",
            },
            {
              title: "Cybersecurity Fundamentals",
              organization: "Public Safety Canada",
              date: "2024",
              description:
                "Internal training on cybersecurity principles, threat detection, and mitigation strategies.",
            },
            {
              title: "Data Analysis with Python",
              organization: "Online Course",
              date: "2023",
              description: "Advanced techniques for data manipulation, analysis, and visualization using Python.",
            },
            {
              title: "DevOps Practices",
              organization: "Internal Workshop",
              date: "2024",
              description: "Hands-on workshop covering CI/CD pipelines, containerization, and infrastructure as code.",
            },
          ].map((cert, index) => (
            <Card key={index} className="border shadow-sm">
              <CardHeader>
                <CardTitle>{cert.title}</CardTitle>
                <CardDescription>
                  {cert.organization} • {cert.date}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p>{cert.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="bg-muted/50 p-8 rounded-lg">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-2xl font-bold">Continuous Learning Philosophy</h2>
          <p className="text-lg">
            I believe that education is a lifelong journey. Beyond formal education, I'm committed to continuous
            learning through online courses, professional certifications, technical reading, and hands-on projects. This
            approach allows me to stay current with emerging technologies and best practices in the rapidly evolving
            fields of software engineering and cybersecurity.
          </p>
        </div>
      </section>

      <div className="flex justify-center">
        <Button asChild>
          <Link href="/contact">
            Contact Me <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

